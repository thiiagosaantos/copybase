export class CreateUploadDto {}
